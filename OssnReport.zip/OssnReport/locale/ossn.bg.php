<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$bg = array(
    'ossn:notifications:ossnreport:report' => "потребителя %s беше докладван!",
    'user:reported' => 'Вие докладвахте %s!',
    'user:report:error' => 'Не успяхте да докладвате.',
    'report' => 'Докладвай',
);
ossn_register_languages('bg', $bg); 