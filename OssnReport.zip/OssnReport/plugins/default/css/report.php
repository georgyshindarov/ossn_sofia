.ossn-notification-icon-report,
.ossn-notification-icon-report:before {
    display: inline-block;	
}
.ossn-notification-icon-report:before {
	content: "\f0a4";
    font-family: 'Font Awesome 5 Free';
    font-style: normal;
    font-weight: normal;
    font-size: 18px;
}